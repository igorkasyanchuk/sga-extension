import React, { Component } from 'react';
import axios from 'axios';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import './App.css';
import 'react-tabs/style/react-tabs.css';

class App extends Component {

  constructor(props) {
    super(props);
    this.state = {
      loading: true,
      status: 'pending'
    }
  }

  componentDidMount() {
    var self = this;
    axios.get('https://solutions.softserveinc.com/account/api/current', { withCredentials: true })
      .then(function (response) {
        console.log(response);
        self.setState({
          loading: false, 
          status: 'finished',
          load: response.data.load.toFixed(2).replace(/\.?0*$/g,'')
        });
      })
      .catch(function (error) {
        self.setState({
          loading: false, 
          status: 'error'
        });
      });
  }

  componentWillUnmount() {
  }

  render() {
    return (
      <div className="App">
        <div className="loadIconContainer">
          <img src="/images/percentage.png" className ="loadIcon"/>
        </div>
        <div className="loadTitle">Current Load</div>
        <div className="loadIconSeparator"></div>
        <div className="currentLoad">
          {this.state.load}
          <span className='percentage'>%</span>
        </div>

        <Tabs className="appTabsContainer">
          <TabList>
            <Tab>Title 1</Tab>
            <Tab>Title 2</Tab>
          </TabList>

          <TabPanel>
            <h2>Any content 1</h2>
          </TabPanel>
          <TabPanel>
            <h2>Any content 2</h2>
          </TabPanel>
        </Tabs>
      </div>
    );
  }
}

export default App;
